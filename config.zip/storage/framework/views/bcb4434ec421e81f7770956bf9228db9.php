

<?php $__env->startSection('breadcrumbs'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb my-3">
    <li class="breadcrumb-item"><a href="<?php echo e(route('companies.index')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('companies.index')); ?>">Companies</a></li>
    <li class="breadcrumb-item active" aria-current="page">Show</li>
  </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4><?php echo e($company->name); ?></h4>
                </div>
                <div class="card-body">
                    <?php if($company->logo): ?>
                        <img src="<?php echo e(Storage::url($company->logo)); ?>" alt="<?php echo e($company->name); ?>" class="img-thumbnail mb-3" style="width:100px; height:100px; object-fit:cover;">
                    <?php endif; ?>
                    <ul class="list-group">
                        <li class="list-group-item"><strong>Email:</strong> <?php echo e($company->email); ?></li>
                        <li class="list-group-item"><strong>Address:</strong> <?php echo e($company->address); ?></li>
                        <li class="list-group-item"><strong>Website:</strong>
                            <?php if($company->website): ?>
                                <a href="<?php echo e($company->website); ?>" target="_blank"><?php echo e($company->website); ?></a>
                            <?php else: ?>
                                <span class="text-muted">No website</span>
                            <?php endif; ?>
                        </li>
                    </ul>
                    <div class="mt-3">
                        <a href="<?php echo e(route('companies.edit', $company)); ?>" class="btn btn-warning">Edit</a>
                        <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-secondary">Back to List</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Sites\Admin-Panel\Admin-Panel\resources\views/companies/show.blade.php ENDPATH**/ ?>