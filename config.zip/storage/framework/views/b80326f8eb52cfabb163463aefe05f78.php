

<?php $__env->startSection('breadcrumbs'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb my-3">
    <li class="breadcrumb-item"><a href="<?php echo e(route('employees.index')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('employees.index')); ?>">Employees</a></li>
    <li class="breadcrumb-item active" aria-current="page">Show</li>
  </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span>Employee Details</span>
                    <a href="<?php echo e(route('employees.edit', $employee->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>First Name:</strong> <?php echo e($employee->first_name); ?></li>
                        <li class="list-group-item"><strong>Last Name:</strong> <?php echo e($employee->last_name); ?></li>
                        <li class="list-group-item"><strong>Company:</strong> <?php echo e($employee->company->name ?? '-'); ?></li>
                        <li class="list-group-item"><strong>Email:</strong> <?php echo e($employee->email); ?></li>
                        <li class="list-group-item"><strong>Phone:</strong> <?php echo e($employee->phone); ?></li>
                    </ul>
                </div>
                <div class="card-footer text-end">
                    <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-secondary">Back to List</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Sites\Admin-Panel\Admin-Panel\resources\views/employees/show.blade.php ENDPATH**/ ?>