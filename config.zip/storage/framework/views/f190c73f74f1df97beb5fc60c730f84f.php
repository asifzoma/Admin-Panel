

<?php $__env->startSection('breadcrumbs'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb my-3">
    <li class="breadcrumb-item"><a href="<?php echo e(route('companies.index')); ?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Companies</li>
  </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Companies</h4>
                    <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-primary">Add New Company</a>
                </div>
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('companies.index')); ?>" class="mb-3">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search by name or email"
                                   value="<?php echo e(request('search')); ?>">
                            <button class="btn btn-outline-secondary" type="submit">Search</button>
                            <?php if(request('search')): ?>
                                <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-outline-danger">Clear</a>
                            <?php endif; ?>
                        </div>
                    </form>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($companies->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Logo</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Website</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if($company->logo): ?>
                                                    <img src="<?php echo e(Storage::url($company->logo)); ?>" 
                                                         alt="<?php echo e($company->name); ?>" 
                                                         class="img-thumbnail" 
                                                         style="width: 50px; height: 50px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="bg-secondary text-white d-flex align-items-center justify-content-center" 
                                                         style="width: 50px; height: 50px;">
                                                        <i class="fas fa-building"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($company->name); ?></td>
                                            <td><?php echo e($company->email); ?></td>
                                            <td>
                                                <?php if($company->website): ?>
                                                    <a href="<?php echo e($company->website); ?>" target="_blank"><?php echo e($company->website); ?></a>
                                                <?php else: ?>
                                                    <span class="text-muted">No website</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="<?php echo e(route('companies.show', $company)); ?>" 
                                                       class="btn btn-sm btn-info">View</a>
                                                    <a href="<?php echo e(route('companies.edit', $company)); ?>" 
                                                       class="btn btn-sm btn-warning">Edit</a>
                                                    <form action="<?php echo e(route('companies.destroy', $company)); ?>" 
                                                          method="POST" 
                                                          style="display: inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" 
                                                                class="btn btn-sm btn-danger" 
                                                                onclick="return confirm('Are you sure you want to delete this company?')">
                                                            Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="d-flex justify-content-center">
                            <?php echo e($companies->links()); ?>

                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <h5 class="text-muted">No companies found</h5>
                            <p>Start by adding your first company.</p>
                            <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-primary">Add Company</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Sites\Admin-Panel\Admin-Panel\resources\views/companies/index.blade.php ENDPATH**/ ?>