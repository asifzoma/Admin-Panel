<?php

namespace App\Http\Controllers;

class Controller
{
    // Base controller for all other controllers
}
